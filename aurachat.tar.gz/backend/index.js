require('dotenv').config();
const { makeWASocket, useMultiFileAuthState, DisconnectReason, Browsers, isJidGroup, fetchLatestBaileysVersion, extractMessageContent, messageType } = require('@whiskeysockets/baileys');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const fastify = require('fastify')({ logger: true });
const fs = require('fs');
const path = require('path');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

// Configurações
const PORT = 3000;
const SECRET_KEY = process.env.SESSION_SECRET || 'fallback-secret';

// Servir Frontend Estático
fastify.register(require('@fastify/static'), {
  root: path.join(__dirname, '../frontend/dist'),
  prefix: '/', 
  wildcard: false // Não usar wildcard no prefixo
});

// Suporte para Refresh (F5) em rotas do React
fastify.setNotFoundHandler((req, reply) => {
  reply.sendFile('index.html');
});
// ============ DATABASE ============
const DB_FILE = path.join(__dirname, 'database.json');
let db = { 
  contacts: {}, 
  config: { 
    botName: 'Sonia', 
    aiPrompt: 'Você é a Sonia, assistente virtual ultra-rápida da Pereira Acabamentos. Seu objetivo é qualificar o lead e agendar visitas ou passar para um consultor humano.', 
    geminiKey: process.env.GEMINI_KEY || '' 
  },
  users: [],
  team: [
    { id: '1', name: 'Taine Neto', role: 'gestor', avatar: 'TN', active: true },
    { id: '3', name: 'Consultor 01', role: 'vendedor', avatar: 'V1', active: true }
  ],
  departments: [{ id: '1', name: 'Vendas', color: '#2563eb' }]
};

// Aguarda o servidor estar pronto para o Socket.io
let io;
fastify.ready(err => {
  if (err) throw err;
  io = require('socket.io')(fastify.server, { cors: { origin: '*' } });
  console.log('✅ Socket.io acoplado ao servidor');
});

async function initDB() {
  const salt = await bcrypt.genSalt(10);
  const hash = await bcrypt.hash('1234', salt);
  
  db.users = [
    { id: '1', user: 'admin', pass: hash, name: 'Administrador', role: 'gestor', avatar: 'AD' },
    { id: '2', user: 'toine', pass: hash, name: 'Taine Neto', role: 'gestor', avatar: 'TN' },
    { id: '3', user: 'vendedor1', pass: hash, name: 'Consultor Vendas 01', role: 'vendedor', avatar: 'V1' }
  ];
  return db;
}

(async () => {
  if (fs.existsSync(DB_FILE)) { 
    try { 
      const savedData = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); 
      if (!savedData.users || savedData.users.length === 0) {
        db = await initDB();
        db = { ...db, ...savedData }; 
      } else {
        db = { ...db, ...savedData }; 
      }
    } catch (err) { 
      console.error("Erro ao ler DB:", err); 
      db = await initDB();
    } 
  } else {
    db = await initDB();
  }
  saveDB();
})();

const saveDB = () => { fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf8'); };

// ============ AUTH MIDDLEWARE ============
async function authenticateToken(req, reply) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return reply.code(401).send({ success: false, message: 'Token não fornecido' });

  try {
    const decoded = jwt.verify(token, SECRET_KEY);
    req.user = decoded;
  } catch (err) {
    return reply.code(403).send({ success: false, message: 'Token inválido ou expirado' });
  }
}

let aiQueue = [];
let isProcessingQueue = false;

function enqueueAIRequest(jid, socket) {
  if (!aiQueue.includes(jid)) aiQueue.push(jid);
  processAIQueue(socket);
}

async function processAIQueue(socket) {
  if (isProcessingQueue || aiQueue.length === 0) return;
  isProcessingQueue = true;
  while (aiQueue.length > 0) {
    const jid = aiQueue.shift();
    await new Promise(r => setTimeout(r, 4000)); // Delay para parecer humano
    try { await executeAICall(jid, socket); } catch (err) { console.error("Erro Fluxo Sonia:", err.message); }
  }
  isProcessingQueue = false;
}

async function executeAICall(jid, socket) {
  const c = db.contacts[jid];
  if (!c || !c.bot_active || !db.config.geminiKey) return;
  
  await socket.sendPresenceUpdate('composing', jid);
  
  const h = c.msgs.slice(-12).map(m => ({
    role: m.type === 'in' ? 'user' : 'model',
    parts: [{ text: m.text.trim() }]
  }));
  
  if (h.length === 0 || h[h.length-1].role !== 'user') return;

  try {
    const genAI = new GoogleGenerativeAI(db.config.geminiKey.trim());
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" }); // Corrigido para modelo estável

    const result = await model.generateContent({ 
        contents: h, 
        systemInstruction: db.config.aiPrompt.replace(/\r/g, '').trim()
    });
    const reply = result.response.text();
    
    if (reply) {
      await socket.sendPresenceUpdate('paused', jid);
      await socket.sendMessage(jid, { text: reply });
      c.msgs.push({ id: Date.now().toString(), type: 'out', text: reply, time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }), bot: true });
      c.msg = reply;
      saveDB();
      io.emit('crm_update', Object.values(db.contacts));
    }
  } catch (err) {
    console.error("❌ ERRO GEMINI:", err.message);
    await socket.sendPresenceUpdate('paused', jid);
  }
}

// ============ API ROUTES ============
fastify.register(require('@fastify/cors'), { origin: '*' });

// Auth
fastify.post('/login', async (req, reply) => {
  const { user, pass } = req.body;
  const found = db.users.find(u => u.user === user.toLowerCase());
  
  if (found && await bcrypt.compare(pass, found.pass)) {
    const token = jwt.sign({ id: found.id, user: found.user, role: found.role }, SECRET_KEY, { expiresIn: '24h' });
    return { success: true, token, user: { id: found.id, name: found.name, role: found.role, avatar: found.avatar } };
  }
  reply.code(401).send({ success: false, message: 'Credenciais inválidas' });
});

// Protected Routes
fastify.get('/contacts', { preHandler: [authenticateToken] }, async () => Object.values(db.contacts));
fastify.get('/messages', { preHandler: [authenticateToken] }, async () => {
  return Object.values(db.contacts).flatMap(c => c.msgs.map(m => ({ ...m, remoteJid: c.id })));
});

fastify.get('/team', { preHandler: [authenticateToken] }, async () => db.team);

fastify.get('/stats', { preHandler: [authenticateToken] }, async () => {
  const all = Object.values(db.contacts);
  const today = new Date().toISOString().split('T')[0];
  const newLeadsToday = all.filter(c => c.createdAt?.startsWith(today)).length;
  const activeBots = all.filter(c => c.bot_active).length;
  const humanLeads = all.filter(c => c.status === 'active').length;
  const waitingLeads = all.filter(c => c.status === 'new').length;
  
  // Calculate sources based on first message (simple heuristic)
  const sources = { direct: 0, instagram: 0, google: 0, other: 0 };
  all.forEach(c => {
    if (c.msgs && c.msgs.length > 0) {
      const firstMsg = c.msgs[0].text.toLowerCase();
      if (firstMsg.includes('instagram') || firstMsg.includes('insta')) sources.instagram++;
      else if (firstMsg.includes('google') || firstMsg.includes('pesquisa')) sources.google++;
      else if (firstMsg.includes('Indicacao') || firstMsg.includes('indicação')) sources.other++;
      else sources.direct++;
    } else {
      sources.direct++;
    }
  });

  return {
    totalLeads: all.length,
    todayLeads: newLeadsToday,
    activeBots: activeBots,
    humanQueue: humanLeads,
    waitingQueue: waitingLeads,
    conversionRate: all.length > 0 ? Math.round((humanLeads / all.length) * 100) : 0,
    sources
  };
});

// ENVIO EM MASSA (BROADCAST)
let isBroadcasting = false;
fastify.post('/broadcast', { preHandler: [authenticateToken] }, async (req, reply) => {
  const { jids, message } = req.body;
  
  if (!auraSocket || !jids || !message || isBroadcasting) {
    return reply.code(400).send({ success: false, message: 'Parâmetros inválidos ou envio em curso' });
  }

  isBroadcasting = true;
  console.log(`📣 [MASSA] Iniciando envio para ${jids.length} contatos...`);

  (async () => {
    for (let i = 0; i < jids.length; i++) {
      const jid = jids[i];
      try {
        await auraSocket.sendMessage(jid, { text: message });
        
        if (db.contacts[jid]) {
          db.contacts[jid].msgs.push({ 
            id: Date.now().toString(), 
            type: 'out', 
            text: `[MASSA] ${message}`, 
            time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) 
          });
          db.contacts[jid].msg = message;
        }

        const delay = Math.floor(Math.random() * 5000) + 3000;
        await new Promise(r => setTimeout(r, delay));
        
        io.emit('broadcast_progress', { current: i + 1, total: jids.length, jid });
      } catch (err) {
        console.error(`❌ Erro no broadcast para ${jid}:`, err.message);
      }
    }
    isBroadcasting = false;
    saveDB();
    io.emit('crm_update', Object.values(db.contacts));
    io.emit('broadcast_finished', { total: jids.length });
  })();

  return { success: true, message: 'Broadcast iniciado' };
});

// Transferência Real
fastify.post('/transfer', { preHandler: [authenticateToken] }, async (req) => {
  const { jid, userId } = req.body;
  if (db.contacts[jid]) {
    db.contacts[jid].status = 'active'; 
    db.contacts[jid].bot_active = false; 
    db.contacts[jid].assignedTo = userId;
    saveDB();
    io.emit('crm_update', Object.values(db.contacts));
    return { success: true };
  }
  return { success: false };
});

fastify.post('/send', { preHandler: [authenticateToken] }, async (req) => {
  const { jid, message } = req.body;
  if (!auraSocket || !jid || !message) return { success: false };
  
  // Emit typing status
  io.emit('typing', { jid, status: true });
  
  await auraSocket.sendMessage(jid, { text: message });
  
  if (db.contacts[jid]) {
    db.contacts[jid].msgs.push({ id: Date.now().toString(), type: 'out', text: message, time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) });
    db.contacts[jid].msg = message;
    saveDB();
    io.emit('crm_update', Object.values(db.contacts));
  }
  
  io.emit('typing', { jid, status: false });
  return { success: true };
});

fastify.post('/toggle-bot', { preHandler: [authenticateToken] }, async (req) => {
  const { jid, status } = req.body;
  if (db.contacts[jid]) {
    db.contacts[jid].bot_active = status;
    saveDB();
    io.emit('crm_update', Object.values(db.contacts));
    return { success: true };
  }
  return { success: false };
});

fastify.post('/logout-wa', { preHandler: [authenticateToken] }, async (req, reply) => {
  if (auraSocket) {
    auraSocket.end(undefined);
    auraSocket = null;
    return { success: true, message: 'WhatsApp disconnectado. Reconectando...' };
  }
  return { success: false, message: 'Nenhuma conexão ativa' };
});

// ============ WHATSAPP SERVICE ============
let auraSocket = null;
async function connectToWhatsApp() {
  try {
    const { state, saveCreds } = await useMultiFileAuthState('baileys_auth_info');
    const { version } = await fetchLatestBaileysVersion();
    const socket = makeWASocket({ 
      version, 
      auth: state, 
      printQRInTerminal: true,
      browser: Browsers.macOS('Aura CRM'),
      msgRetryCounterCache: true
    });

    auraSocket = socket;
    socket.ev.on('creds.update', saveCreds);
    socket.ev.on('connection.update', (u) => { 
      if (u.connection === 'close') {
        const shouldReconnect = u.lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
        if (shouldReconnect) connectToWhatsApp();
      }
    });

    socket.ev.on('messages.upsert', async (m) => {
      const msg = m.messages[0];
      if (!msg.message || msg.key.fromMe) return;
      
      const jid = msg.key.remoteJid;
      if (isJidGroup(jid)) return;

      let msgText = "";
      let msgType = "text";

      // Extract text
      if (msg.message.conversation) msgText = msg.message.conversation;
      else if (msg.message.extendedTextMessage) msgText = msg.message.extendedTextMessage.text;
      
      // Check for media
      if (!msgText) {
        if (msg.message.imageMessage) {
          msgText = "[Imagem]";
          msgType = "image";
        } else if (msg.message.audioMessage) {
          msgText = "[Áudio]";
          msgType = "audio";
        } else if (msg.message.videoMessage) {
          msgText = "[Vídeo]";
          msgType = "video";
        } else if (msg.message.stickerMessage) {
          msgText = "[Sticker]";
          msgType = "sticker";
        } else {
          return; // Ignore other message types
        }
      }

      if (!db.contacts[jid]) {
        db.contacts[jid] = { 
          id: jid, 
          name: msg.pushName || 'Cliente Novo', 
          phone: jid.split('@')[0], 
          createdAt: new Date().toISOString(), 
          msg: msgText, 
          status: 'new', 
          msgs: [], 
          bot_active: true 
        };
      }

      db.contacts[jid].msgs.push({ id: msg.key.id, type: 'in', text: msgText, msgType, time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) });
      db.contacts[jid].msg = msgText;
      saveDB();
      io.emit('crm_update', Object.values(db.contacts));
      
      if (db.contacts[jid].bot_active && db.config.geminiKey && msgType === 'text') enqueueAIRequest(jid, socket);
    });
  } catch (err) {
    console.error("Erro Conexão WhatsApp:", err);
  }
}

fastify.listen({ port: PORT, host: '0.0.0.0' }, (err, address) => {
    if (err) { 
        console.error('❌ Erro ao iniciar servidor:', err); 
        process.exit(1); 
    }
    console.log(`🚀 [BACKEND] Aura CRM Ativo: ${address} (PORTA ${PORT})`);
    connectToWhatsApp();
});
