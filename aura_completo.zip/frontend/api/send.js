// Proxy para envio de mensagens WhatsApp via GCP Backend
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const GCP_URL = process.env.GCP_BACKEND_URL || 'http://136.118.48.181:3001';
  if (!GCP_URL) {
    return res.status(500).json({ success: false, error: 'GCP_BACKEND_URL não configurado' });
  }

  try {
    const response = await fetch(`${GCP_URL}/send`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': req.headers.authorization || ''
      },
      body: JSON.stringify(req.body)
    });
    const data = await response.json();
    return res.status(response.status).json(data);
  } catch (error) {
    return res.status(500).json({ success: false, error: error.message });
  }
}
