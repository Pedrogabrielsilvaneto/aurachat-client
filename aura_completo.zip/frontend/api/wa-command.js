// Proxy para Comandos WhatsApp no GCP Backend
export default async function handler(req, res) {
  const GCP_URL = process.env.GCP_BACKEND_URL || 'http://136.118.48.181:3001';

  try {
    const options = {
      method: req.method,
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': req.headers.authorization || ''
      }
    };

    if (req.method === 'POST') {
      options.body = JSON.stringify(req.body);
    }

    const response = await fetch(`${GCP_URL}/wa-command`, options);
    const data = await response.json();
    return res.status(response.status).json(data);
  } catch (error) {
    console.error('Proxy Error (wa-command):', error.message);
    return res.status(500).json({ success: false, error: error.message });
  }
}
