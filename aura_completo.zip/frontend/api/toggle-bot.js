// Proxy para toggle-bot via GCP Backend
import { kv } from '@vercel/kv';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { jid, status } = req.body;

  // Atualiza localmente no KV também
  try {
    let contacts = await kv.get('aura_contacts');
    if (contacts) {
      contacts = contacts.map(c => 
        c.id === jid ? { ...c, bot_active: status } : c
      );
      await kv.set('aura_contacts', contacts);
    }
  } catch (e) {
    console.error('Erro ao atualizar KV:', e.message);
  }

  // Envia para o GCP Backend
  const GCP_URL = process.env.GCP_BACKEND_URL || 'http://136.118.48.181:3001';
  if (!GCP_URL) {
    return res.status(200).json({ success: true, local: true });
  }

  try {
    const response = await fetch(`${GCP_URL}/toggle-bot`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': req.headers.authorization || ''
      },
      body: JSON.stringify({ jid, status })
    });
    const data = await response.json();
    return res.status(response.status).json(data);
  } catch (error) {
    return res.status(200).json({ success: true, local: true });
  }
}
