// Proxy para WhatsApp Status no GCP Backend
export default async function handler(req, res) {
  const GCP_URL = process.env.GCP_BACKEND_URL || 'http://136.118.48.181:3001';

  try {
    const response = await fetch(`${GCP_URL}/wa-status`, {
      method: 'GET',
      headers: { 
        'Authorization': req.headers.authorization || ''
      }
    });
    const data = await response.json();
    return res.status(response.status).json(data);
  } catch (error) {
    console.error('Proxy Error (wa-status):', error.message);
    return res.status(500).json({ status: 'error', error: error.message });
  }
}

