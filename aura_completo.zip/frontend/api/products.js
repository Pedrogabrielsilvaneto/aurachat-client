// Proxy para Produtos no GCP Backend
export default async function handler(req, res) {
  const GCP_URL = process.env.GCP_BACKEND_URL || 'http://136.118.48.181:3001';

  try {
    const options = {
      method: req.method,
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': req.headers.authorization || ''
      }
    };

    if (['POST', 'PUT', 'PATCH'].includes(req.method)) {
      options.body = JSON.stringify(req.body);
    }

    const url = new URL(`${GCP_URL}/products`);
    if (req.method === 'DELETE' && req.query.id) {
       url.searchParams.append('id', req.query.id);
    }

    const response = await fetch(url.toString(), options);
    const data = await response.json();
    return res.status(response.status).json(data);
  } catch (error) {
    console.error('Proxy Error (products):', error.message);
    return res.status(500).json({ success: false, error: error.message });
  }
}
