// Proxy para Login no GCP Backend
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const GCP_URL = process.env.GCP_BACKEND_URL || 'http://136.118.48.181:3001';

  try {
    const response = await fetch(`${GCP_URL}/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req.body)
    });
    const data = await response.json();
    return res.status(response.status).json(data);
  } catch (error) {
    console.error('Proxy Error (login):', error.message);
    return res.status(500).json({ success: false, error: error.message });
  }
}

